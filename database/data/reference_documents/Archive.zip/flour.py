from fractions import Fraction

flourWeights = {'semolina flour': 167,'cake flour': 137,'white whole wheat flour': 125,'regular whole wheat flour': 120,'durum wheat flour': 125,'whole wheat pastry flour': 136,'whole wheat flour': 152,'bread flour': 144,'graham flour': 120,'instant flour': 120,'Wondra': 120,'pastry flour': 136,'pumpernickel flour': 120,'rye flour': 128,'self-rising flour': 120,'spelt flour': 120,'whole wheat bread flour': 152,'durum flour': 144,'kamut flour': 120,'barley flour': 120,'triticale flour': 130,'wholemeal flour': 152,'gluten flour': 120,'enriched flour': 120,'plain flour': 120,'atta flour': 152,'maida flour': 152,'noodle flour': 120,'high gluten flour': 152,'first clear flour': 120,'white whole wheat': 152,'enriched all-purpose flour': 125,'bleached enriched all-purpose flour': 125,'unbleached enriched all-purpose flour': 136,'bleached all-purpose flour': 125,'unbleached all-purpose flour': 125,'bolted flour': 120,'self-rising cake flour': 137,'clear flour': 128,'farina': 176,'cream of wheat': 176,'patent flour': 128,'extra short patent flour': 128,'fancy patent flour': 128,'first patent flour': 152,'short patent flour': 152,'medium patent flour': 136,'long patent flour': 136,'fancy clear flour': 152,'second clear flour': 152,'stuffed straight flour': 150,'vital wheat gluten': 120,'wheat germ': 115,'bran': 94,'unprocessed bran': 94,'plain wholemeal flour': 120,'hard whole wheat flour': 120,'stone ground whole wheat flour': 120,'whole wheat white flour': 120,'buckwheat flour': 120,'chia flour': 233,'flax meal': 104,'corn meal': 128,'hemp flour': 128,'lupin flour': 120,'maize flour': 110.4,'oat flour': 104,'soy flour': 105,'amaranth flour': 120,'arrowroot flour': 128,'chickpea flour': 92,'garbanzo bean flour': 120,'lentil flour': 92,'fava bean flour': 132,'corn flour': 117,'masa harina': 110.4,'millet flour': 119,'quinoa flour': 112,'white rice flour': 158,'brown rice flour': 158,'sorghum flour': 121,'sweet rice flour': 204,'potato flour': 181,'teff flour': 120,'potato starch': 170,'tapioca starch': 125,'cornstarch': 128,'arrowroot starch': 120,'acorn starch': 120,'xanthum gum': 112,'guar gum': 112,'almond flour': 120,'hazelnut flour': 112,'walnut flour': 120,'cashew flour': 120,'chesnut flour': 100,'coconut flour': 112};

flour = {'corn flour':{'quantity': "1 3/4", 'gluten': 'false'}};
print type(flour)
def flower(flour, quantity):
    for i in range(len(flourWeights)):
        for f in flourWeights:
            newquantity = 0
            if f in flour:
                flour['weight'] = flourWeights[f]
                print flour['weight']
                if "/" in quantity:
                    newquantity = float(sum(Fraction(s) for s in quantity.split()))
                    if "/" in quantity:
                        newqs = []
                        newq = quantity.split("/")
                        for i in newq:
                            i = i.split()
                            newqs = newqs + i
                            print newqs[0]
                            print newqs[1]
                        n = int(newqs[0])
                        d = int(newq[1])
                        t = float(n/d)
                        print t
                    else:
                        newq = quantity.split()
                        newquantity = int(newq[0])/int(newq[1])
                        print newquantity
                else:
                    # newquantity = int(quantity)
                    print newquantity
            elif i < len(flourWeights):
            #     continue
                totalweight = newquantity*flour['weight']
        return totalweight
print flower(flour, '1 3/4')